#include <iostream>
#include <string>
#include <map>

using namespace std;

int main() {
    map<string, string> post_data;
    string line;
    while (getline(cin, line)) {
        size_t pos = line.find('=');
        if (pos != string::npos) {
            string key = line.substr(0, pos);
            string value = line.substr(pos + 1);
            post_data[key] = value;
        }
    }

    string status = post_data["status"];
    string order_id = post_data["order_id"];
    string remark1 = post_data["remark1"];

    if (status == "SUCCESS") {
        // Process the data here as needed
        // For example, log it or perform other actions

        // Respond to the webhook with a success message
        cout << "Webhook received successfully" << endl;
    } else {
        // Respond with an error message if the status is not "SUCCESS"
        cout << "Invalid status: " << status << endl;
    }

    return 0;
}
