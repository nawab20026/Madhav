require 'sinatra'

post '/' do
  status = params['status']
  order_id = params['order_id']
  remark1 = params['remark1']

  if status == 'SUCCESS'
    # Process the data here as needed
    # For example, log it or perform other actions

    "Webhook received successfully"
  else
    status 400 # Bad Request
    "Invalid status: #{status}"
  end
end

# Handling invalid request methods
not_found do
  status 400 # Bad Request
  'Invalid request method'
end
